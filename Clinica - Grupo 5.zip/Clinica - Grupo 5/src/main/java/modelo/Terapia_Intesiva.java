package modelo;

public class Terapia_Intesiva extends Habitacion
{
	public Terapia_Intesiva(double costoBase)
	{
		super(costoBase);
	}
}
