package modelo;

public class Privada extends Habitacion
{
	public Privada(double costoBase)
	{
		super(costoBase);
	}
}
