package excepciones;

public class NoHayEspecialidadException extends ImposibleCrearMedicoException
{

	public NoHayEspecialidadException(String arg0)
	{
		super(arg0);
	}
	
}
